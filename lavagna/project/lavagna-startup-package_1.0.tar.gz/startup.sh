#!/bin/bash

# Stop all running containers
docker-compose down

# Remove all unused containers, networks, images (both dangling and unreferenced), and optionally, volumes.
docker system prune -f

# Start docker-compose with the new image
docker-compose up -d
